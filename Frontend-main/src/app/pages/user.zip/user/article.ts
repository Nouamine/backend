export interface Article {
    title: string;
    date: string;
    body: string; //  'description'
    imageUrl: string;
  }